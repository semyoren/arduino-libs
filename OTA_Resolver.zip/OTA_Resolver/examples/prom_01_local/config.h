#define WIFI_SSID     ""
#define WIFI_PASSWORD ""

#define URL "IP_ADDRESS_OR_HOST_OF_SERVER" // "192.168.0.1" or "prometheus.yourdomain.local" No http or https, No port or path
#define PATH "/api/v1/write"
#define PORT 9090
